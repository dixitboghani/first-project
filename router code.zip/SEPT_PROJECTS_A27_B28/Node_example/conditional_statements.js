


let x = 2
let y = 55


if (x ===55) {
    console.log("x is 0")
}

else if(x===2){
    console.log("y1")
}

else if(x===2){
    console.log("y2")
}
else if(x ==2){
    console.log("y3")
}
else if(x === 2){
    console.log("y4")
    
}




if (x===2){
    console.log("x ==2 is true")
}