


// while loop

var x = 0;
while (x <= 1000) {

    console.log(x)
    x = x + 1
}


//for loop


for ( let i = 0; i< 1000; i= i+1 ){

console.log(i)
}

console.log(i)