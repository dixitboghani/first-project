

let total = 0
// function give_fullname(a,b) {

//     let total = 0 
//     total = a + b
//     // console.log("my name is xyz")

//     return total;
// }
// var x = give_fullname(2,4)
// console.log (  x   )
// console.log( total  )



var y = function (a,b) {
    console.log("print something")
}

y()
// How to conver function to es 6

const some_function =  (a,b) => {
    console.log("print something")
}