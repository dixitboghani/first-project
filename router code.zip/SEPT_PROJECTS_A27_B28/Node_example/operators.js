
var y = 3

console.log(  2 ===  '2'  )


console.log(  2 !==  '2'  )

console.log(  2 >= 10)

console.log(  2 <= 10)



var x = 5

// x  = x - 2

x -= 2


console.log(x)