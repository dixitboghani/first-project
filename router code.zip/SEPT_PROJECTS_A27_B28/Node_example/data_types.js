
//  Old javascript

// 1. number

var a  = 23.242


// 2. String


var c = 'klasdklasdlk'


// 3. boolean

var d = true // or false


// 4. undefined


var x;
// 5 . null

var y = null
// 6.  Object

var di = {
    
}


console.log(x)

// es 6


let a = 0;
a = 2
const b = 4;

b = 5