

console.log(1)
console.log(2)

setTimeout( ()=> {
    console.log("inside timeout")
}, 3000)

console.log("Finish")