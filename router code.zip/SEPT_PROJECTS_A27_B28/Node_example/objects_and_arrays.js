


let students = ['darshan','akhil','karma','asldfkaslmkdf']

let a = [1,2,3,4,5,6,7,8,9,10]




console.log(    students )



// for ( let i =0 ; i < students.length ; i++ ){


//     console.log(  students[i]   )
// }


let x = {
    // key : value

   name: "karma",
    test : [12,12,1,21,2],
    test2 : {

    }

}


console.log(  x['name is something']   )