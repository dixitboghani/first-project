import React, { Component } from 'react'

class TestPage extends Component {
    constructor(props) {
        super(props)

        this.state = {
                 
        }
    }

    render() {
        return (
            <div>
                Hi this is a test Page
            </div>
        )
    }
}

export default TestPage
