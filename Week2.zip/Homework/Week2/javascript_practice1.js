// 1. 
// Write a JavaScript program which compute, 
// the average marks of the following students Then,
//  this average is used to determine the corresponding grade.

