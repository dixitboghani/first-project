/**
 * Node js function to write to a file.
 */














 /**
 * Node js function to read from file created above.
 */
