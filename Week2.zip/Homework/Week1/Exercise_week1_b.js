const Courses = [
    {id: 1, total_students: 90, name: 'Java', time: 'Monday'},
    {id: 2, total_students: 45, name: 'Python', time: 'Wednesday'},
    {id: 3, total_students: 25, name: 'Python', time: 'Tuesday'},
    {id: 4, total_students: 34, name: 'Java', time: 'Saturday'},
    {id: 5, total_students: 12, name: 'React', time: 'Saturday'},
    {id: 6, total_students: 85, name: 'Node', time: 'Saturday'},
    {id: 7, total_students: 75, name: 'JavaScript', time: 'Friday'},
    {id: 8, total_students: 45, name: 'JavaScript', time: 'Friday'},
    {id: 9, total_students: 23, name: 'Node', time: 'Friday'},
    {id: 10, total_students: 34, name: 'JavaScript', time: 'Sunday'},
]


/**
 * 1. Create New Array with all courses with 'name' === 'Java'
 * Hint use Array.filter or Array.map.
 */

 let Courses_with_name_Java;
//Your code below











 console.log(Courses_with_name_Java)




 /**
 * 2. Write a function that prints out all courses with time === Monday
 */

 
let Courses_with_time_Monday = () =>{
    
};
//Your code below












console.log(Courses_with_time_Monday)

 /**
 * 3. Filter arrays by name. Create new array for each 'name'
 * For Example:
 * Push to below array by their course name.
 * Hint: Use Array.forEach ..... and push
 */


 let java_courses = [];
 let python_courses = [];
 let react_courses = [];
 let node_courses = [];
 let javaScript_courses = [];
 
 
//Your code below











//------




 /**
 * 4. Write a function to reduce total_students by 10 for each object in courses array.
 */

 
let courses_array_with_reduced_students;
//Your code below












console.log(courses_array_with_reduced_students)