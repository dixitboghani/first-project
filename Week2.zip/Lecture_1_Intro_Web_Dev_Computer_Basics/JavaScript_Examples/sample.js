// variables
var karma = "this is example karma. naosdfkldamlkjhakfj";

var karma2 = 5;

karma = "this is another value";



//this part is from newer javascript
const test = "karma";

let test3 = "karma";
test3 = "some value";

var x = 5;
var y = 5.55;
var d = 9.999999999999999999999;


var some_array = ["karma","Kiran","raj",12,4,5];

console.log("this is some data")
console.log(x);