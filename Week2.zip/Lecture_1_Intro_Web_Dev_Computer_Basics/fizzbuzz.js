


const fizzbuzz = () => {









}

fizzbuzz()