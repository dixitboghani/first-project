
var x = 1;
let a = 2;
const v = 0;


const some_function = (variable1,variable2) => {

    return variable1+variable2;
}



let some_array = [1,2,3,4,5,6];
let some_string_array =  ['sad','asdf','asdcadsc'];

let person_object = {
    'youtube_title' :  'dixit',
    phone : 'xnodslakjf',
    id : 1
}

/**
 * person_object.name jaksdkf
 * person_object['name jaksdkf']
 */



let some_object_array = [
    {
        name :  'dixit',
        phone : 'i dont know',
        id : 1,
        class: 'engineering'
    },
    {
        name :  'Chirag',
        phone : 'xnodslakjf',
        id : 2,
        class: 'medical'
    }
    ,
    {
        name :  'tushar',
        phone : 'xnodslakjf',
        id : 3,
        class: 'engineering'
    }
]


// for ( let i=0;i<some_object_array.length;i++){
//     console.log(some_object_array[i]);
// }

// some_object_array.forEach(function(items) {
//     items.id = items.id*50;
// })




// let new_array_by_map = some_object_array.map( (items) => {
//     if(items.id === 2){
//         return "nothing";
//     }
//     return items.id;
// })



// let new_array_by_filter = some_object_array.filter( (items) =>{

//     return items.class === 'engineering'

// })


console.log(1);







