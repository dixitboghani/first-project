const sayHello = () => {

    console.log("Hello world");
}


sayHello()