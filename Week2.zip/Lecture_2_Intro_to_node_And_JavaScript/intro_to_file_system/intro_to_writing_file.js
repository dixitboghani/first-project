const file_system = require('fs');


file_system.writeFileSync('testing.txt','I changed this text')