
const Name = "dixit";



const getMyName = () => {

    return "This is from utils";
}

module.exports = {
    Name,
    getMyName
}