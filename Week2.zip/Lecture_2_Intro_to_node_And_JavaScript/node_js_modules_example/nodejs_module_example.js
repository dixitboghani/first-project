const utils = require('./utils')


console.log(utils.Name)
console.log(utils.getMyName() )