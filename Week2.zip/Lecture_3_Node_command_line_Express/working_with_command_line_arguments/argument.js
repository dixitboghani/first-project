

let some_array = (process.argv).slice(2)



// let some_other_array = [0,1,2,3,4,5,6,7,8,9,10]


// let modified_array = some_other_array.slice(2,5);
// console.log(modified_array)


console.log(some_array);

let first_value = some_array[0];
let second_valeue = some_array[1];
