const ThisFunctionReturnNumberFive = () => {

    return 5;
}

const ThisFunctionReturnNumberTen= () => {

    return 10;
}

module.exports = {
    ThisFunctionReturnNumberFive,
    ThisFunctionReturnNumberTen
}