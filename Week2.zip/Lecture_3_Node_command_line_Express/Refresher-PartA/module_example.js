
const giveMeData = () =>{

    return "some Data";
}


module.exports = {
    giveMeData
}